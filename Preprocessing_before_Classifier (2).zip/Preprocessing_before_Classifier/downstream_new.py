import torch
from torch.utils.data import DataLoader
import clip
import pandas as pd
import torchvision.transforms as transforms
from Dataset_new import PklDataset
from Encoding import encode_data
from Fusion import fuse_features
import pickle

def load_dataset(pickle_file):
    with open(pickle_file, 'rb') as file:
        data = pickle.load(file)
    return data

def get_clip_transforms():
    return transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.48145466, 0.4578275, 0.40821073], std=[0.26862954, 0.26130258, 0.27577711])
    ])

def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, preprocess = clip.load("ViT-B/32", device=device)

    # Load the dataset from pickle file
    dataset_path = 'E:\\GALIP dataset\\datasets_pickle\\train.pkl'
    data = load_dataset(dataset_path)

    print("Dataset keys:", list(data.keys()))  # Print all keys to inspect

    dataset = PklDataset(data, transform=get_clip_transforms())
    print("Length of dataset:", len(dataset))  # Should match the number of keys printed

    dataloader = DataLoader(dataset, batch_size=1, shuffle=True)
    
    try:
        for images, texts in dataloader:
            print("Batch loaded successfully.")
    except Exception as e:
        print("Error loading a batch:", e)

    dataset = PklDataset(data, transform=get_clip_transforms())
    dataloader = DataLoader(dataset, batch_size=1, shuffle=True)
    
    # Process the dataset
    for images, texts in dataloader:
        images, texts = images.to(device), texts
        image_features, text_features = encode_data(model, images, texts, device)
        fused_features = fuse_features(image_features, text_features)

        # Process fused features...
        final_fused_features = torch.cat([fused_text_image_features, new_image_features], dim=1)

if __name__ == "__main__":
    main()