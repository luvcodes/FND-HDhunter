from torch.utils.data import Dataset
from PIL import Image

class PklDataset(Dataset):
    def __init__(self, data, transform=None):
        """
        Initialize with a dictionary where keys might not be continuous integers.
        """
        self.data = data
        self.transform = transform
        self.keys = sorted(data.keys())  # Sort keys to maintain order, if necessary

    def __len__(self):
        return len(self.keys)

    def __getitem__(self, idx):
        key = self.keys[idx]  # Access the data using sorted keys
        item = self.data[key]

        image_path = item['image']
        text = item['original_post']
        
        image = Image.open(image_path).convert('RGB')
        if self.transform:
            image = self.transform(image)

        return image, text