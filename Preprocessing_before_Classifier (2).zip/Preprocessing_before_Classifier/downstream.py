import torch
from torch.utils.data import DataLoader
from torchvision.transforms import Compose, Resize, Normalize, ToTensor
from Dataset import MyDataset
from Encoding import encode_data
from Fusion import fuse_features
import clip
import pandas as pd
from PIL import Image

def get_clip_transforms():
    return Compose([
        Resize((224, 224)),
        ToTensor(),
        Normalize(mean=[0.48145466, 0.4578275, 0.40821073], std=[0.26862954, 0.26130258, 0.27577711])
    ])

def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, preprocess = clip.load("ViT-B/32", device=device)
    
    dataset = MyDataset(
        image_paths=["C:\\Users\\13322\\OneDrive\\文档\\Captone5703\\weibo dataset\\Army officer.jpg"], 
        texts=["Boston Marathon Bomb victim is actually Nick Vogt, former US Army Officer who lost his legs in Kandahar Afghanistan with the 1st Stryker Brig 25th Infantry Division in Nov 2011. There is more going on here than the media will tell!"], 
        transform=get_clip_transforms()
    )
    dataloader = DataLoader(dataset, batch_size=1, shuffle=True)
    
    for images, texts in dataloader:
        images, texts = images.to(device), texts
        image_features, text_features = encode_data(model, images, texts, device)
        fused_text_image_features = fuse_features(image_features, text_features)

    new_image_path = "C:\\Users\\13322\\OneDrive\\文档\\Captone5703\\weibo dataset\\Army officer.jpg"
    new_image = Image.open(new_image_path).convert("RGB")
    new_image = preprocess(new_image).unsqueeze(0).to(device)
    new_image_features = model.encode_image(new_image).float()

    final_fused_features = torch.cat([fused_text_image_features, new_image_features], dim=1)

    # Save or process the final fused features
    pd.DataFrame(final_fused_features.detach().cpu().numpy()).to_csv("final_fused_features.csv", index=False)
    torch.save(final_fused_features, 'final_fused_features.pt')

    # Print the size of the final fused features tensor
    print("Size of the final fused features tensor:", final_fused_features.shape)

if __name__ == "__main__":
    main()