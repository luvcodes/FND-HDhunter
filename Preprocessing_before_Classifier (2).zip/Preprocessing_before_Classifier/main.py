import torch
from torch.utils.data import DataLoader
from Dataset import MyDataset
from Transforms import get_clip_transforms
from Encoding import encode_data
from Fusion import fuse_features
import clip
import pandas as pd

def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model, preprocess = clip.load("ViT-B/32", device=device)
    
    dataset = MyDataset(
        image_paths=["C:\\Users\\13322\\OneDrive\\文档\\Captone5703\\weibo dataset\\Army officer.jpg"], 
        texts=["Boston Marathon Bomb victim is actually Nick Vogt, former US Army Officer who lost his legs in Kandahar Afghanistan with the 1st Stryker Brig 25th Infantry Division in Nov 2011. There is more going on here than the media will tell!"], 
        transform=get_clip_transforms()
    )
    dataloader = DataLoader(dataset, batch_size=1, shuffle=True)
    
    for images, texts in dataloader:
        images, texts = images.to(device), texts
        image_features, text_features = encode_data(model, images, texts, device)
        fused_text_image_features = fuse_features(image_features, text_features)

        # Print the shapes of the features
        print("Shape of image features:", image_features.shape)
        print("Shape of text features:", text_features.shape)
        print("Shape of fused text-image features:", fused_text_image_features.shape)

        # Save the features as CSV files
        pd.DataFrame(image_features.detach().cpu().numpy()).to_csv("image_features.csv", index=False)
        pd.DataFrame(text_features.detach().cpu().numpy()).to_csv("text_features.csv", index=False)
        pd.DataFrame(fused_text_image_features.detach().cpu().numpy()).to_csv("fused_text_image_features.csv", index=False)

        # Save the features as tensor files
        torch.save(image_features, 'image_features.pt')
        torch.save(text_features, 'text_features.pt')
        torch.save(fused_text_image_features, 'fused_text_image_features.pt')

if __name__ == "__main__":
    main()