import pickle

def load_dataset(pickle_file):
    with open(pickle_file, 'rb') as file:
        data = pickle.load(file)
    return data

data = load_dataset('E:\\GALIP dataset\\datasets_pickle\\train.pkl')

# Define a function to print a preview of the data
def print_preview(data_key):
    if data_key in data:
        print(f"Data for '{data_key}':")
        print("Type:", type(data[data_key]))
        # Print only the first 100 characters if it's a string, or the first item if it's a list
        if isinstance(data[data_key], str):
            print("Preview:", data[data_key][:100])
        elif isinstance(data[data_key], list) and len(data[data_key]) > 0:
            print("Preview:", data[data_key][0])
        else:
            print("Content:", data[data_key])
        print("\n-------------------\n")
    else:
        print(f"Key '{data_key}' not found in the dataset.")

# Specify the keys you're interested in
keys_of_interest = ['post_text', 'original_post', 'image']

# Print a preview of the data for each key
for key in keys_of_interest:
    print_preview(key)